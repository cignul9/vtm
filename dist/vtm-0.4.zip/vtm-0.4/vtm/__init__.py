<<<<<<< HEAD
__version__ = '0.4'
=======
__version__ = '0.3'
>>>>>>> refs/remotes/origin/master
__author__ = 'Shawn Magill'
__all__ = [ 'VtmConnection', 'VtmConfig' ]

from .vtm import VtmConnection, VtmConfig
