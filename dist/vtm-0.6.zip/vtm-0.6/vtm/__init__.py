__version__ = '0.6'
__author__ = 'Shawn Magill'
__all__ = [ 'VtmConnection', 'VtmConfig' ]

from .vtm import VtmConnection, VtmConfig
