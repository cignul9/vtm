__version__ = '1.0'
__author__ = 'Shawn Magill'
__all__ = [ 'VtmConnection', 'VtmConfig' ]

from .vtm import VtmConnection, VtmConfig
